
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
# from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, get_user_model
from django.utils import timezone
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import *
from .models import User, Locations
from django.db.models import Q

User = get_user_model()

def home_view(request):
    # if request.method == 'POST':
    return render(request,'registration/home.html')

def login_view(request):
    if request.method == 'POST':
        # 处理用户提交的登录表单
        email = request.POST.get('username')
        password = request.POST.get('password')
        user = None
        try:
            user = User.objects.get(email=email)  # Retrieve user by email
        except User.DoesNotExist:
            return render(request, 'registration/login.html', {'error_message': 'Invalid email or password.'})
        user = authenticate(request, username=user.username, password=password)
        if user is not None:
            # 用户认证成功，登录用户
            login(request, user)
            user.last_access_date = timezone.now()
            
            user.save()

            return redirect('homeInterface') # return render(request,'registration/home.html')  # 重定向到用户主页或其他页面
        else:
            # 用户认证失败，显示登录页面并提示错误信息
            return render(request, 'registration/login.html', {'error_message': 'Invalid username or password.'})
    else:
        # 显示登录页面
        return render(request, 'registration/login.html')

def register_view(request):
    if request.method == 'POST':
        # 处理用户提交的注册表单

        username = request.POST.get('username')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        description = request.POST.get('profile_description')
        picture = request.FILES.get('profile_picture')
        

        # address = request.POST.get('address', 'Default Address')
        # latitude = request.POST.get('latitude', 0.0)  # 默认值为0.0
        # longitude = request.POST.get('longitude', 0.0)  # 默认值为0.0
        # 创建新用户账户
        user = User.objects.create_user(username=username, email=email, 
                                        password=password, first_name=first_name,
                                        last_name=last_name, profile_description=description,
                                        profile_picture = picture,
                                        registration_date = timezone.now())
        user.save()
        # location = Locations.objects.create(
        #     address=address,
        #     latitude=latitude,
        #     longitude=longitude
        # )
        # location.save()
        return redirect('login')  # 注册成功后重定向到登录页面
    else:
        # 显示注册页面
        return render(request, 'registration/registra.html')

def homeInterface_view(request):
    return render(request,'registration/HomeInterface.html')

def logout_view(request):
    # 注销用户并重定向到注销成功页面
    logout(request)
    return render(request, 'registration/logout.html')

@login_required
def user_profile(request):
    """ API to fetch user profile details """
    if request.method == 'GET':
        data = {
            'username': request.user.username,
            'profile_description': request.user.profile_description,
            'profile_picture': request.user.profile_picture.url if request.user.profile_picture else None,
            'registration_date': request.user.registration_date,
            'last_access_date': request.user.last_access_date,
            'user_id': request.user.    user_id
        }
        return JsonResponse(data)

# @login_required
# def user_friends(request):
#     """ API to fetch friends and neighbors """
#     if request.method == 'GET':
#         friends = Friendships.objects.filter(user1=request.user).select_related('user2').order_by('-creation_date')
#         friends_list = [
#             {
#                 'username': friend.user2.username,
#                 'profile_description': friend.user2.profile_description,
#                 'profile_picture': friend.user2.profile_picture.url if friend.user2.profile_picture else None,
#                 'status': friend.status,
#                 'creation_date': friend.creation_date
#             }
#             for friend in friends
#         ]
#         neighbors = Neighbors.objects.filter(user=request.user).select_related('neighbor_user').order_by('-creation_date')
#         neighbors_list = [
#             {
#                 'username': neighbor.neighbor_user.username,
#                 'profile_description': neighbor.neighbor_user.profile_description,
#                 'profile_picture': neighbor.neighbor_user.profile_picture.url if neighbor.neighbor_user.profile_picture else None,
#                 # 'creation_date': neighbor.neighbor_user.date_joined.isoformat()  # Assuming you have a date_joined field or similar
#             }
#             for neighbor in neighbors
#         ]

#         # Return combined data
#         return JsonResponse({'friends': friends_list, 'neighbors': neighbors_list}, safe=False)
from django.db.models import Q
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from .models import Friendships, Neighbors

@login_required
def user_friends(request):
    if request.method == 'GET':
        # Fetching friends where the current user is either user1 or user2 and status is 'Accepted'
        friends = Friendships.objects.filter(
            (Q(user1=request.user) | Q(user2=request.user)),
            status='Accepted'
        ).prefetch_related('user1', 'user2').order_by('-creation_date')
        
        # List comprehension to prepare friends data excluding the current user
        friends_list = [
            {
                'username': friend.user2.username if friend.user1 == request.user else friend.user1.username,
                'profile_description': friend.user2.profile_description if friend.user1 == request.user else friend.user1.profile_description,
                'profile_picture': friend.user2.profile_picture.url if friend.user1 == request.user else friend.user1.profile_picture.url,
                'status': friend.status,
                'creation_date': friend.creation_date,
                'user_id':friend.user2.user_id if friend.user1 == request.user else friend.user1.user_id,
            }
            for friend in friends if (friend.user1 != request.user or friend.user2 != request.user)
        ]


        # 获取邻居关系，类似地避免重复
        neighbors = Neighbors.objects.filter(
            Q(user=request.user) | Q(neighbor_user=request.user)
        ).select_related('user', 'neighbor_user').order_by('-creation_date')

        neighbors_list = [
            {
                'username': neighbor.neighbor_user.username if neighbor.user == request.user else neighbor.user.username,
                'profile_description': neighbor.neighbor_user.profile_description if neighbor.user == request.user else neighbor.user.profile_description,
                'profile_picture': neighbor.neighbor_user.profile_picture.url if neighbor.user == request.user else neighbor.user.profile_picture.url,
                'creation_date': neighbor.neighbor_user.date_joined.isoformat() if neighbor.user == request.user else neighbor.user.date_joined.isoformat(),
                'user_id': neighbor.neighbor_user.user_id if neighbor.user == request.user else neighbor.user.user_id,
            }
            for neighbor in neighbors
        ]
        # Return combined data
        return JsonResponse({'friends': friends_list, 'neighbors': neighbors_list}, safe=False)

def user_details(request, user_id):
    user_info = get_object_or_404(User, pk=user_id)
    return render(request, 'registration/user_details.html', {'user': user_info})

