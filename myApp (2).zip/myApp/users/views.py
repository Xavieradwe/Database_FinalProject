
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
# from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, get_user_model
from django.utils import timezone

User = get_user_model()

def home_view(request):
    # if request.method == 'POST':
    return render(request,'registration/home.html')

def login_view(request):
    if request.method == 'POST':
        # 处理用户提交的登录表单
        email = request.POST.get('username')
        password = request.POST.get('password')
        user = None
        try:
            user = User.objects.get(email=email)  # Retrieve user by email
        except User.DoesNotExist:
            return render(request, 'registration/login.html', {'error_message': 'Invalid email or password.'})
        user = authenticate(request, username=user.username, password=password)
        if user is not None:
            # 用户认证成功，登录用户
            login(request, user)
            user.last_access_date = timezone.now()
            user.save()
            return redirect('home') # return render(request,'registration/home.html')  # 重定向到用户主页或其他页面
        else:
            # 用户认证失败，显示登录页面并提示错误信息
            return render(request, 'registration/login.html', {'error_message': 'Invalid username or password.'})
    else:
        # 显示登录页面
        return render(request, 'registration/login.html')

def register_view(request):
    if request.method == 'POST':
        # 处理用户提交的注册表单

        username = request.POST.get('username')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        description = request.POST.get('profile_description')
        picture = request.FILES.get('profile_picture')
        
        # 创建新用户账户
        user = User.objects.create_user(username=username, email=email, 
                                        password=password, first_name=first_name,
                                        last_name=last_name, profile_description=description,
                                        profile_picture = picture,
                                        registration_date = timezone.now())
        user.save()

        return redirect('login')  # 注册成功后重定向到登录页面
    else:
        # 显示注册页面
        return render(request, 'registration/registra.html')

def logout_view(request):
    # 注销用户并重定向到注销成功页面
    logout(request)
    return render(request, 'registration/logout.html')