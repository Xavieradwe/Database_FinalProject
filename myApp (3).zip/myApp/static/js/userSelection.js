document.addEventListener("DOMContentLoaded", function() {
    fetchUserProfile();
    fetchFriendsAndNeighbors();
});

function fetchUserProfile() {
    fetch('/api/profile')
        .then(response => response.json())
        .then(data => {
            document.getElementById('user-profile').innerHTML = `
            <div class="friend-item">
                <img src="${data.profile_picture}" alt="Profile Picture" class ="friend-pic">
                <p>${data.username}</p>
            </div>
            `;
        });
}

function fetchFriendsAndNeighbors() {
    fetch('/api/friends')
        .then(response => response.json())
        .then(data => {
            const friendsElement = document.getElementById('friends-list');
            data.friends.forEach(friend => {
                friendsElement.innerHTML += `
                    <div class = "friend-item">
                     <img src="${friend.profile_picture}" alt="Friend Picture" class = "friend-pic">
                        <p>${friend.username}</p>
                    </div>
                `;
            });
            data.neighbors.forEach(neighbor => {
                friendsElement.innerHTML += `
                    <div class = "neighbor-item">
                        <img src="${neighbor.profile_picture}" alt="Neighbor Picture" class = "neighbor-pic">
                        <p>${neighbor.username}</p>
                    </div>
                `;
            });
        });
}
