document.addEventListener("DOMContentLoaded", function() {
    fetchUserProfile();
    fetchFriendsAndNeighbors();
});

function fetchUserProfile() {
    fetch('/api/profile')
        .then(response => response.json())
        .then(data => {
            document.getElementById('user-profile').innerHTML = `
                <p>${data.username}</p>
                <img src="${data.profile_picture}" alt="Profile Picture">
            `;
        });
}

function fetchFriendsAndNeighbors() {
    fetch('/api/friends')
        .then(response => response.json())
        .then(data => {
            const friendsElement = document.getElementById('friends-list');
            data.friends.forEach(friend => {
                friendsElement.innerHTML += `
                    <div>
                        <p>${friend.username}</p>
                        <img src="${friend.profile_picture}" alt="Friend Picture">
                    </div>
                `;
            });
            data.neighbors.forEach(neighbor => {
                friendsElement.innerHTML += `
                    <div>
                        <p>${neighbor.username}</p>
                        <img src="${neighbor.profile_picture}" alt="Neighbor Picture">
                    </div>
                `;
            });
        });
}
